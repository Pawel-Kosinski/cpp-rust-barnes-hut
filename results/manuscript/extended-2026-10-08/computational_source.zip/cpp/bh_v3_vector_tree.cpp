#include <iostream>
#include <vector>
#include "node.hpp"
#include <algorithm>
#include "timer.hpp"
#include <fstream> 
#include <cmath>
#include <iomanip>
#include "benchmark_options.hpp"
#include "diagnostics.hpp"

constexpr float G = 1.0f;
float THETA = 0.3f;
using Node = NodeV3;

struct Particle
{
    float velocityX{0.0f};
    float velocityY{0.0f};
    float accX{0.0f};
    float accY{0.0f};
    float mass{0.0f};
    float posX{0.0f};
    float posY{0.0f};
    int nextDuplicate{-1};
};

int getQuadrant(const Node& node, const Particle& particle) 
{
    int index = 0; 

    if (particle.posX > node.boundsX) 
    {
        index += 1; 
    }

    if (particle.posY > node.boundsY) 
    {
        index += 2; 
    }

    return index;
}
void insertParticle(int nodeIdx, int pIdx, std::vector<Node>& arena, std::vector<Particle>& particles)
{
    if (arena[nodeIdx].particleIndex != -1) 
    {
        int oldIdx = arena[nodeIdx].particleIndex;
        if (particles[pIdx].posX == particles[oldIdx].posX && particles[pIdx].posY == particles[oldIdx].posY)
        {
            particles[pIdx].nextDuplicate = oldIdx;
            arena[nodeIdx].particleIndex = pIdx;
            return;
        }
    }

    if (arena[nodeIdx].particleIndex == -1 && arena[nodeIdx].children[0] == -1)
    {
        arena[nodeIdx].particleIndex = pIdx;
        return;
    }
    if (arena[nodeIdx].children[0] != -1)
    {
        int quadrant = getQuadrant(arena[nodeIdx], particles[pIdx]);
        insertParticle(arena[nodeIdx].children[quadrant], pIdx, arena, particles);
        return;
    }

    int oldPIdx = arena[nodeIdx].particleIndex;
    arena[nodeIdx].particleIndex = -1;
    for (int i = 0; i < 4; ++i)
    {
        Node child;
        child.halfSize = arena[nodeIdx].halfSize / 2.0f;
        child.boundsX = arena[nodeIdx].boundsX + ((i % 2) * 2 - 1) * child.halfSize;
        child.boundsY = arena[nodeIdx].boundsY + ((i / 2) * 2 - 1) * child.halfSize;
        arena[nodeIdx].children[i] = static_cast<int>(arena.size());
        arena.push_back(child);
    }
    insertParticle(nodeIdx, oldPIdx, arena, particles);
    insertParticle(nodeIdx, pIdx, arena, particles);
}

void computeMassDistribution(int nodeIdx, std::vector<Node>& arena, const std::vector<Particle>& particles)
{
    Node& node = arena[nodeIdx];
    if (node.children[0] != -1)
    {
        node.mass = 0.0f;
        node.centerX = 0.0f;
        node.centerY = 0.0f;
        for (int i = 0; i < 4; ++i)
        {
            int childIdx = node.children[i];
            computeMassDistribution(childIdx, arena, particles);
            float childMass = arena[childIdx].mass;
            node.mass += childMass;

            node.centerX += arena[childIdx].centerX * childMass;
            node.centerY += arena[childIdx].centerY * childMass;
        }
        if (node.mass > 0.0f)
        {
            node.centerX /= node.mass;
            node.centerY /= node.mass;
        }
    }

    else if(node.particleIndex != -1)
    {
        node.mass = 0.0f;
        node.centerX = 0.0f;
        node.centerY = 0.0f;
        for (int sourceIdx = node.particleIndex; sourceIdx != -1; sourceIdx = particles[sourceIdx].nextDuplicate)
        {
            const Particle& source = particles[sourceIdx];
            node.mass += source.mass;
            node.centerX += source.posX * source.mass;
            node.centerY += source.posY * source.mass;
        }
        if (node.mass > 0.0f)
        {
            node.centerX /= node.mass;
            node.centerY /= node.mass;
        }
    }
    else 
    {
        node.mass = 0.0f;
        node.centerX = 0.0f;
        node.centerY = 0.0f;
    }
}

struct PhysicsMetrics {
    double totalMomentumX = 0.0;
    double totalMomentumY = 0.0;
    double totalKineticEnergy = 0.0;
    double centerX = 0.0;
    double centerY = 0.0;
};

PhysicsMetrics calculatePhysicsDiagnostics(const std::vector<Particle>& particles) {
    PhysicsMetrics m;
    double totalMass = 0.0;

    for (const auto& p : particles) {
        double mass = static_cast<double>(p.mass);
        double vx = static_cast<double>(p.velocityX);
        double vy = static_cast<double>(p.velocityY);
        double px = static_cast<double>(p.posX);
        double py = static_cast<double>(p.posY);

        m.totalMomentumX += mass * vx;
        m.totalMomentumY += mass * vy;
        m.totalKineticEnergy += 0.5 * mass * (vx * vx + vy * vy);

        m.centerX += mass * px;
        m.centerY += mass * py;
        totalMass += mass;
    }

    m.centerX /= totalMass;
    m.centerY /= totalMass;

    return m;
}

void calculateForcesRecursive(int pIdx, int nodeIdx, std::vector<Particle>& particles, const std::vector<Node>& arena)
{
    if (nodeIdx == -1) return;

    Particle& p = particles[pIdx];
    const Node& node = arena[nodeIdx];
    if (node.mass <= 0.0f) return;

    if (node.children[0] == -1)
    {
        for (int sourceIdx = node.particleIndex; sourceIdx != -1; sourceIdx = particles[sourceIdx].nextDuplicate)
        {
            if (sourceIdx == pIdx) continue;
            const Particle& source = particles[sourceIdx];
            float dx = source.posX - p.posX;
            float dy = source.posY - p.posY;
            float distSq = dx * dx + dy * dy;
            if (distSq < 1e-5f) continue;
            float dist = std::sqrt(distSq);
            float acc = G * source.mass / (distSq + 1.0f);
            p.accX += acc * (dx / dist);
            p.accY += acc * (dy / dist);
        }
        return;
    }

    float dx = node.centerX - p.posX;
    float dy = node.centerY - p.posY;
    float distSq = dx * dx + dy * dy;
    bool containsTarget = std::abs(p.posX - node.boundsX) <= node.halfSize
        && std::abs(p.posY - node.boundsY) <= node.halfSize;

    float side_length = node.halfSize * 2.0f;
    float r_c_sq = (side_length * side_length) * 0.5f; // (s_c * sqrt(2)/2)^2 = s_c^2 * 0.5
    if (!containsTarget && distSq >= 1e-5f && r_c_sq < THETA * THETA * distSq)
    {
        float dist = std::sqrt(distSq);
        float acc = G * node.mass / (distSq + 1.0f);
        p.accX += acc * (dx / dist);
        p.accY += acc * (dy / dist);
    }
    else
    {

        for (int i = 0; i < 4; ++i)
        {
            if (node.children[i] != -1)
            {
                calculateForcesRecursive(pIdx, node.children[i], particles, arena);
            }
        }
    }
}

int mainMain(const BenchmarkOptions& options)
{
    std::vector<Particle> particles;
    std::vector<Node> treeArena;
    Timer timer;
    double totalTreeBuildTime = 0.0;
    double totalForceTime = 0.0;
    double totalKernelTime = 0.0;
    double totalUpdateTime = 0.0;

    std::ifstream inFile(options.input);
    if (!inFile)
    {
        std::cerr << "Error: Could not open file " << options.input << "!\n";
        return 1;
    }

    Particle p;
    p.accX = 0.0f;
    p.accY = 0.0f;
    
    while (inFile >> p.posX >> p.posY >> p.velocityX >> p.velocityY >> p.mass)
    {
        particles.push_back(p);
    }
    inFile.close();
    if (!validateParticleCount(options, particles.size())) return 1;

    //treeArena.reserve(particles.size() * 10);

    DiagnosticWriter<std::vector<Particle>> diagnostics(options.diagnostics, options.timeStep, options.diagnosticStride);
    diagnostics.record(0, particles);

    for (int frame = 0; frame < options.totalFrames(); ++frame)
    {
        timer.start(); 
        float minX = particles[0].posX, maxX = particles[0].posX;
        float minY = particles[0].posY, maxY = particles[0].posY;
        
        for (const auto& particle : particles)
        {
            if (particle.posX < minX) minX = particle.posX;
            if (particle.posX > maxX) maxX = particle.posX;
            if (particle.posY < minY) minY = particle.posY;
            if (particle.posY > maxY) maxY = particle.posY;
        }

        float centerX = (minX + maxX) / 2.0f;
        float centerY = (minY + maxY) / 2.0f;
        float halfWidth = (maxX - minX) / 2.0f;
        float halfHeight = (maxY - minY) / 2.0f;
        float maxHalfSize = std::max(halfWidth, halfHeight) + 1.0f;

        treeArena.clear();
        Node root; 
        root.boundsX = centerX; 
        root.boundsY = centerY; 
        root.halfSize = maxHalfSize;
        treeArena.push_back(root);

        for (auto& particle : particles) particle.nextDuplicate = -1;
        for (std::size_t i = 0; i < particles.size(); ++i)
        {
            insertParticle(0, static_cast<int>(i), treeArena, particles);
        }

        // if (frame == 0) {
        //     // Particle array size:
        //     size_t particlesMem = particles.capacity() * sizeof(Particle);
        //     // Maximum reserved tree-arena size:
        //     size_t treeMem = treeArena.capacity() * sizeof(Node);

        //     std::cout << std::fixed << std::setprecision(6);
        //     double totalAppMemMB = static_cast<double>(particlesMem + treeMem) / (1024.0 * 1024.0);
        //     std::cout << "algorithm memory usage: " << totalAppMemMB << " MB\n";
        //     std::cout << "Created " << treeArena.size() << " tree nodes.\n";
        //     std::cout << "Size of Particle: " << sizeof(Particle) << " bytes\n";
        //     std::cout << "Size of Node (V3): " << sizeof(Node) << " bytes\n";
        // }

        computeMassDistribution(0, treeArena, particles);
        const double treeTime = timer.stopTime();
        if (frame >= options.warmupFrames) totalTreeBuildTime += treeTime;
        if (frame == options.warmupFrames && !options.memoryReport.empty()) {
            writeMemoryReport(options.memoryReport, treeArena.size(), sizeof(Node), treeArena.capacity(), 1,
                              particles.capacity() * sizeof(Particle), 0);
        }

        timer.start();
        for (std::size_t i = 0; i < particles.size(); ++i)
        {
            calculateForcesRecursive(static_cast<int>(i), 0, particles, treeArena);
        }

        const double kernelTime = timer.stopTime();
        if (frame == options.warmupFrames && !writeForces(options.dumpForces, particles, options.forceSamples)) return 1;
        timer.start();

        for (auto& particle : particles)
        {
            particle.velocityX += particle.accX * options.timeStep;
            particle.velocityY += particle.accY * options.timeStep;
            particle.posX += particle.velocityX * options.timeStep;
            particle.posY += particle.velocityY * options.timeStep;
            
            particle.accX = 0.0f;
            particle.accY = 0.0f;
        }
        const double updateTime = timer.stopTime();
        if (frame >= options.warmupFrames) {
            totalKernelTime += kernelTime;
            totalUpdateTime += updateTime;
            totalForceTime += kernelTime + updateTime;
        }
        diagnostics.record(frame + 1, particles, frame + 1 == options.totalFrames());
    }
    std::cout << std::fixed << std::setprecision(6);
    writeState(options.dumpState, particles);
    std::cout << "Force kernel time: " << (totalKernelTime / options.frames) << " ms / frame\n";
    std::cout << "State update time: " << (totalUpdateTime / options.frames) << " ms / frame\n";
    std::cout << "Tree construction time: " << (totalTreeBuildTime / options.frames) << " ms / frame\n";
    std::cout << "Force/update time: " << (totalForceTime / options.frames) << " ms / frame\n";
    std::cout << "Cleanup time: 0.000000 ms / frame\n";
    std::cout << "Total measured time: " << (totalTreeBuildTime + totalForceTime) << " ms\n";
    // std::ifstream outFile("reference_5000k.txt");
    // if (!outFile) 
    // {
    //     std::cout << "file error.\n";
    // } 
    // else 
    // {
    //     float totalError = 0.0f;
    //     float maxError = 0.0f;
    //     float refX = 0.0f, refY = 0.0f;
        
    //     for (const auto& p : particles)
    //     {
    //         outFile >> refX >> refY;
            
    //         float dx = p.posX - refX;
    //         float dy = p.posY - refY;
    //         float currentError = std::sqrt(dx * dx + dy * dy);
    //         totalError += currentError;
    //         if (currentError > maxError) {
    //             maxError = currentError; 
    //         }
    //     }
    //     outFile.close();
        
    //     float meanAbsoluteError = totalError / NUM_PARTICLES;
    //     std::cout << "Mean absolute position error (MAE): " << meanAbsoluteError << " units\n";
    //     std::cout << "Maximum position error: " << maxError << " units\n";
    // }
    return 0;
}

int main(int argc, char** argv)
{
    BenchmarkOptions options;
    if (!parseBenchmarkOptions(argc, argv, options)) return argc > 1 ? 1 : 0;
    THETA = options.theta;
    return mainMain(options);
}
